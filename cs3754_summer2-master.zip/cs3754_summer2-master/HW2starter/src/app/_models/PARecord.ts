
import {PAType} from './PAType';

export class PARecord {

  calories: number;
  minutes: number;
  caloriegoal: number;
  minutegoal: number;
  steps: number;
  activityType: PAType;
  createdDate: Date;
  }

