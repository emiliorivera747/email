export enum Role {
  user = 'User',
  admin = 'Admin'
}
