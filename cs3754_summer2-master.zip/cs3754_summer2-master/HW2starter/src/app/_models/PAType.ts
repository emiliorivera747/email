export enum PAType {
  running,
  walking,
  biking
}
